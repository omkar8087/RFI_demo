package com.ob.rfi;

public class Coverage {
	
	private String RFI_NODE_Id;
	private String RFI_CHKL_Id;
	private String RFI_GRP_Id;
	private String RFI_Coverage_var;
	public String getRFI_NODE_Id() {
		return RFI_NODE_Id;
	}
	public void setRFI_NODE_Id(String rFI_NODE_Id) {
		RFI_NODE_Id = rFI_NODE_Id;
	}
	public String getRFI_CHKL_Id() {
		return RFI_CHKL_Id;
	}
	public void setRFI_CHKL_Id(String rFI_CHKL_Id) {
		RFI_CHKL_Id = rFI_CHKL_Id;
	}
	public String getRFI_GRP_Id() {
		return RFI_GRP_Id;
	}
	public void setRFI_GRP_Id(String rFI_GRP_Id) {
		RFI_GRP_Id = rFI_GRP_Id;
	}
	public String getRFI_Coverage_var() {
		return RFI_Coverage_var;
	}
	public void setRFI_Coverage_var(String rFI_Coverage_var) {
		RFI_Coverage_var = rFI_Coverage_var;
	}
	
	
	
}
