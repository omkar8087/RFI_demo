package com.ob.rfi;

public class Group {

	private String groupID;
	private String groupName;
	private String nodeID;
	private String checkListID;
	private String groupSequenceInt;
	
	public String getGroupID() {
		return groupID;
	}
	public void setGroupID(String groupID) {
		this.groupID = groupID;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getNodeID() {
		return nodeID;
	}
	public void setNodeID(String nodeID) {
		this.nodeID = nodeID;
	}
	public String getCheckListID() {
		return checkListID;
	}
	public void setCheckListID(String checkListID) {
		this.checkListID = checkListID;
	}
	public String getGroupSequenceInt() {
		return groupSequenceInt;
	}
	public void setGroupSequenceInt(String groupSequenceInt) {
		this.groupSequenceInt = groupSequenceInt;
	}
	
}
